// Ido Levy 318949294
import biuoop.GUI;
import biuoop.DrawSurface;
import java.util.Random;
import java.awt.Color;
/**
 * Represents an abstract art drawing.
 */
public class AbstractArtDrawing {
    private static final int WIDTH = 400;
    private static final int HEIGHT = 300;
    private static final int NUM_OF_LINES = 10;
    private static final int CIRCLE_RADIUS = 3;
    /**
     * This method generates an abstract art drawing by randomly generating lines and marking their middle points and
     * intersections.
     * The drawing is displayed on a GUI window.
     * @param args This parameter is not used.
     */
    public static void main(String[] args) {
        Frame frame = new Frame(Frame.GUI_UPPER_LEFT, WIDTH, HEIGHT, null);
        Random random = new Random();
        Line[] lines = new Line[NUM_OF_LINES];
        GUI gui = new GUI("Abstract Art Drawing", WIDTH, HEIGHT);
        DrawSurface drawSurface = gui.getDrawSurface();
        for (int i = 0; i < NUM_OF_LINES; ++i) {
            lines[i] = Line.generateRandomLine(frame, random);
            lines[i].drawOn(drawSurface);
            Util.mark(lines[i].middle(), Color.BLUE, drawSurface, CIRCLE_RADIUS);
        }
        for (int i = 0; i < NUM_OF_LINES - 1; ++i) {
            for (int j = i + 1; j < NUM_OF_LINES; ++j) {
                Point intersectionPoint = lines[i].intersectionWith(lines[j]);
                if (intersectionPoint != null) {
                    Util.mark(intersectionPoint, Color.RED, drawSurface, CIRCLE_RADIUS);
                }
            }
        }
        gui.show(drawSurface);
    }
}